package net.conczin.immersive_paintings.config;

import me.fzzyhmstrs.fzzy_config.annotations.Translation;
import me.fzzyhmstrs.fzzy_config.config.Config;
import me.fzzyhmstrs.fzzy_config.config.ConfigGroup;
import net.conczin.immersive_paintings.ImmersivePaintings;

@Translation(prefix = "config." + ImmersivePaintings.MOD_ID + ".client")
public class ClientConfig extends Config {
    public ClientConfig() {
        super(ImmersivePaintings.locate("client_config"));
    }

    public ConfigGroup generalGroup = new ConfigGroup("general");
    public boolean loadPaintings = true;
    public boolean showOtherPlayersPaintings = true;
    public boolean cacheOtherPlayersPaintings = false;
    @ConfigGroup.Pop
    public boolean showNSFWPaintings = true;
    public float nsfwBlurAmount = 0.25f;

    public ConfigGroup advancedGroup = new ConfigGroup("advanced");
    public int thumbnailSize = 128;
    public int lodResolutionMinimum = 32;

    public float halfResolutionThreshold = 4.0f;
    public float quarterResolutionThreshold = 8.0f;
    @ConfigGroup.Pop
    public float thumbResolutionThreshold = 16.0f;
}
