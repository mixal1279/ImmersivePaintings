package net.conczin.immersive_paintings.client.render;

import net.conczin.immersive_paintings.ImmersivePaintings;
import net.conczin.immersive_paintings.client.render.state.ImmersivePaintingRenderState;
import net.conczin.immersive_paintings.config.ClientConfig;
import net.conczin.immersive_paintings.entity.ImmersivePaintingEntity;
import net.conczin.immersive_paintings.ClientPaintingManager;
import net.conczin.immersive_paintings.Painting;
import net.conczin.immersive_paintings.registry.Config;
import net.conczin.immersive_paintings.resources.ObjectLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.util.LightCoordsUtil;
import owens.oobjloader.Face;
import owens.oobjloader.FaceVertex;

import java.util.List;
import java.util.Optional;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;

public class ImmersivePaintingRenderer<T extends ImmersivePaintingEntity> extends EntityRenderer<T, ImmersivePaintingRenderState> {
    public ImmersivePaintingRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ImmersivePaintingRenderState createRenderState() {
        return new ImmersivePaintingRenderState();
    }

    @Override
    public void extractRenderState(T entity, ImmersivePaintingRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);

        state.light = LightCoordsUtil.getLightCoords(entity.level(), entity.blockPosition());

        state.xRot = entity.getXRot(partialTick);
        state.yRot = entity.getYRot(partialTick);
        state.isGlowing = entity.isGlowing();
        state.isGraffiti = entity.isGraffiti();
        state.widthPixels = entity.getPaintingWidth() * 16;
        state.heightPixels = entity.getPaintingHeight() * 16;

        state.frame = entity.getFrame();
        state.material = entity.getMaterial();

        Minecraft client = Minecraft.getInstance();
        ClientConfig config = Config.CLIENT;

        double distance = (client.player == null ? 0 : client.player.distanceTo(entity));
        double blocksVisible = Math.tan(client.options.fov().get() / 180.0 * Math.PI / 2.0) * 2.0 * distance;

        Optional<Painting> painting = ClientPaintingManager.getPainting(entity.getMotive());
        if (painting.isEmpty()) {
            state.texture = ClientPaintingManager.getImageIdentifier(Painting.DEFAULT_IDENTIFIER, Painting.Size.FULL);
            return;
        }

        double pixelDensity = blocksVisible * painting.get().resolution() / client.getWindow().getHeight();

        Painting.Size size = pixelDensity > config.thumbResolutionThreshold ? Painting.Size.THUMBNAIL
                : pixelDensity > config.quarterResolutionThreshold ? Painting.Size.QUARTER
                : pixelDensity > config.halfResolutionThreshold ? Painting.Size.HALF
                : Painting.Size.FULL;

        state.texture = ClientPaintingManager.getImageIdentifier(entity.getMotive(), size);
    }

    // TODO
    @Override
    protected int getBlockLightLevel(T entity, BlockPos pos) {
        int parentLight = super.getBlockLightLevel(entity, pos);
        return entity.isGlowing() ? Math.max(5, parentLight) : parentLight;
    }

    @Override
    public void submit(ImmersivePaintingRenderState renderState, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState cameraState) {
        if (ClientPaintingManager.arePaintingsHidden()) return;

        super.submit(renderState, poseStack, collector, cameraState);

        poseStack.pushPose();
        poseStack.mulPose(new Matrix4f().rotateY((float) Math.toRadians(-renderState.yRot)));
        poseStack.mulPose(new Matrix4f().rotateX((float) Math.toRadians(-renderState.xRot)));
        poseStack.scale(0.0625f, 0.0625f, 0.0625f);

        boolean hasFrame = !renderState.frame.equals(ImmersivePaintings.NONE_LOCATION);

        //canvas
        String name = renderState.isGraffiti ? "objects/graffiti.obj" : "objects/canvas.obj";
        collector.submitCustomGeometry(
                poseStack,
                renderState.isGraffiti ? RenderTypes.entityTranslucent(renderState.texture) : RenderTypes.entitySolid(renderState.texture),
                (pose, vertexConsumer) -> renderFaces(name, pose, vertexConsumer, getLight(renderState.light, renderState.isGlowing), renderState.widthPixels, renderState.heightPixels, hasFrame ? 1.0f : 0.0f)
        );

        //frame
        if (hasFrame) {
            collector.submitCustomGeometry(
                    poseStack,
                    RenderTypes.entityCutout(renderState.material),
                    (pose, vertexConsumer) -> renderFrame(renderState.frame, pose, vertexConsumer, getFrameLight(renderState.light, renderState.isGlowing), renderState.widthPixels, renderState.heightPixels)
            );
        }

        poseStack.popPose();
    }

    protected int getLight(int light, boolean glowing) {
        if (!glowing)
            return light;

        return LightCoordsUtil.pack((int)(LightCoordsUtil.block(light) * 0.25 + 15 * 0.75), LightCoordsUtil.sky(light));
    }

    protected int getFrameLight(int light, boolean glowing) {
        if (!glowing)
            return light;

        return LightCoordsUtil.pack((int)(LightCoordsUtil.block(light) * 0.875 + 2), LightCoordsUtil.sky(light));
    }

    public static void renderFaces(String name, PoseStack.Pose pose, VertexConsumer vertexConsumer, int light, float width, float height, float margin) {
        List<Face> faces = ObjectLoader.objects.get(ImmersivePaintings.locate(name));
        for (Face face : faces) {
            for (FaceVertex v : face.vertices) {
                vertex(pose,
                        vertexConsumer,
                        v.v.x * (width - margin * 2),
                        v.v.y * (height - margin * 2),
                        v.v.z * 16.0f,
                        v.t.u * (width - margin * 2) / width + margin / width,
                        (1.0f - v.t.v) * (height - margin * 2) / height + margin / height,
                        v.n.x,
                        v.n.y,
                        v.n.z,
                        light);
            }
        }
    }

    private List<Face> getFaces(Identifier frame, String part) {
        Identifier id = Identifier.fromNamespaceAndPath(frame.getNamespace(), frame.getPath() + "/" + part + ".obj");
        if (ObjectLoader.objects.containsKey(id)) {
            return ObjectLoader.objects.get(id);
        }
        return List.of();
    }

    private void renderFrame(Identifier frame, PoseStack.Pose pose, VertexConsumer vertexConsumer, int light, float width, float height) {
        List<Face> faces = getFaces(frame, "bottom");
        for (int x = 0; x < width / 16; x++) {
            float u = width == 16 ? 0.75f : (x == 0 ? 0.0f : x == width / 16 - 1 ? 0.5f : 0.25f);
            for (Face face : faces) {
                for (FaceVertex v : face.vertices) {
                    vertex(pose, vertexConsumer, v.v.x + x * 16 - (width - 16) / 2, v.v.y - (height - 16) / 2, v.v.z, v.t.u * 0.25f + u, (1.0f - v.t.v), v.n.x, v.n.y, v.n.z, light);
                }
            }
        }
        faces = getFaces(frame, "top");
        for (int x = 0; x < width / 16; x++) {
            float u = width == 16 ? 0.75f : (x == 0 ? 0.0f : x == width / 16 - 1 ? 0.5f : 0.25f);
            for (Face face : faces) {
                for (FaceVertex v : face.vertices) {
                    vertex(pose, vertexConsumer, v.v.x + x * 16 - (width - 16) / 2, v.v.y + (height - 16) / 2, v.v.z, v.t.u * 0.25f + u, (1.0f - v.t.v), v.n.x, v.n.y, v.n.z, light);
                }
            }
        }
        faces = getFaces(frame, "right");
        for (int y = 0; y < height / 16; y++) {
            float u = 0.25f;
            for (Face face : faces) {
                for (FaceVertex v : face.vertices) {
                    vertex(pose, vertexConsumer, v.v.x + (width - 16) / 2, v.v.y + y * 16 - (height - 16) / 2, v.v.z, v.t.u * 0.25f + u, (1.0f - v.t.v), v.n.x, v.n.y, v.n.z, light);
                }
            }
        }
        faces = getFaces(frame, "left");
        for (int y = 0; y < height / 16; y++) {
            float u = 0.25f;
            for (Face face : faces) {
                for (FaceVertex v : face.vertices) {
                    vertex(pose, vertexConsumer, v.v.x - (width - 16) / 2, v.v.y + y * 16 - (height - 16) / 2, v.v.z, v.t.u * 0.25f + u, (1.0f - v.t.v), v.n.x, v.n.y, v.n.z, light);
                }
            }
        }
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer vertexConsumer, float x, float y, float z, float u, float v, float normalX, float normalY, float normalZ, int light) {
        vertexConsumer.addVertex(pose, x, y, z - 0.5f).setColor(255, 255, 255, 255).setUv(u, v).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, normalX, normalY, normalZ);
    }
}
